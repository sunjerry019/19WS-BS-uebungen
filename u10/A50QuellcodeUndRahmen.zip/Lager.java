public class Lager {
    private int aepfel;
    private int apfelmus;

    public Lager(int aepfel, int apfelmus) {




    }

    public synchronized void aepfelEinlagern(int anzahl) {
        aepfel = aepfel + anzahl;
        System.out.println(anzahl + " Aepfel eingelagert, Anz. Aepfel:" + aepfel);
        notifyAll();
    }

    public synchronized void apfelmusEntnehmen(int id, int anzahl) throws InterruptedException {
        while (                                                         ) {
            System.out.println("Identitaet " + id + 
					" muss warten. Anz. apfelmus:" + apfelmus);




        }
        System.out.println(anzahl + " Apfelmus entnommen von " + id + 
					" , Anz. Apfelmus:" + apfelmus);



    }

    public synchronized void aepfelEntnehmen(int anzahl) throws InterruptedException {
        while (                                                         ) {
            System.out.println("Koch muss warten. Anz. Aepfel:" + aepfel);
            



        }
        System.out.println(anzahl + " Aepfel entnommen, Anz. Aepfel:" + aepfel);




    }

    public synchronized void apfelmusEinlagern(int anzahl) {





    }
}
